Project White - Exploratory Data Analysis & Random Forest Classification
of Legendary Types
================
by Team White - John Quinlan, Kristian Alleyne, Dominique Mben Tuang,
Ryan Malani

## Summary

Overview Project White delves into the depths of Pokémon data, analyzing
various attributes to uncover insights that can aid trainers in their
quests. Our team utilizes a detailed dataset comprising 802 Pokémon from
all seven generations, capturing an array of attributes such as base
stats, types, and legendary status. The objective of this project is to
harness these data to predict the legendary status of Pokémon using
machine learning techniques, specifically Random Forest Classification.
This document presents our methodologies, from data preprocessing to
model evaluation, and discusses the implications of our findings.

Data Preparation The dataset required significant preprocessing to make
it suitable for analysis. This involved cleaning data, transforming
categorical variables into numerical formats, and addressing missing
values. Key transformations included normalizing names and types of
Pokémon to a consistent format, ensuring all categorical variables were
appropriately encoded for the Random Forest algorithm.

    ## ── Attaching core tidyverse packages ──────────────────────── tidyverse 2.0.0 ──
    ## ✔ dplyr     1.1.4     ✔ readr     2.1.5
    ## ✔ forcats   1.0.0     ✔ stringr   1.5.1
    ## ✔ ggplot2   3.5.0     ✔ tibble    3.2.1
    ## ✔ lubridate 1.9.3     ✔ tidyr     1.3.1
    ## ✔ purrr     1.0.2     
    ## ── Conflicts ────────────────────────────────────────── tidyverse_conflicts() ──
    ## ✖ dplyr::filter() masks stats::filter()
    ## ✖ dplyr::lag()    masks stats::lag()
    ## ℹ Use the conflicted package (<http://conflicted.r-lib.org/>) to force all conflicts to become errors
    ## Rows: 801 Columns: 41
    ## ── Column specification ────────────────────────────────────────────────────────
    ## Delimiter: ","
    ## chr  (7): abilities, capture_rate, classfication, japanese_name, name, type_...
    ## dbl (34): against_bug, against_dark, against_dragon, against_electric, again...
    ## 
    ## ℹ Use `spec()` to retrieve the full column specification for this data.
    ## ℹ Specify the column types or set `show_col_types = FALSE` to quiet this message.

    ## Rows: 801
    ## Columns: 41
    ## $ abilities         <chr> "['Overgrow', 'Chlorophyll']", "['Overgrow', 'Chloro…
    ## $ against_bug       <dbl> 1.00, 1.00, 1.00, 0.50, 0.50, 0.25, 1.00, 1.00, 1.00…
    ## $ against_dark      <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1…
    ## $ against_dragon    <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1…
    ## $ against_electric  <dbl> 0.5, 0.5, 0.5, 1.0, 1.0, 2.0, 2.0, 2.0, 2.0, 1.0, 1.…
    ## $ against_fairy     <dbl> 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1.0, 1.0, 1.0, 1.0, 1.…
    ## $ against_fight     <dbl> 0.50, 0.50, 0.50, 1.00, 1.00, 0.50, 1.00, 1.00, 1.00…
    ## $ against_fire      <dbl> 2.0, 2.0, 2.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 2.0, 2.…
    ## $ against_flying    <dbl> 2.0, 2.0, 2.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.…
    ## $ against_ghost     <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0…
    ## $ against_grass     <dbl> 0.25, 0.25, 0.25, 0.50, 0.50, 0.25, 2.00, 2.00, 2.00…
    ## $ against_ground    <dbl> 1.0, 1.0, 1.0, 2.0, 2.0, 0.0, 1.0, 1.0, 1.0, 0.5, 0.…
    ## $ against_ice       <dbl> 2.0, 2.0, 2.0, 0.5, 0.5, 1.0, 0.5, 0.5, 0.5, 1.0, 1.…
    ## $ against_normal    <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1…
    ## $ against_poison    <dbl> 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.…
    ## $ against_psychic   <dbl> 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1…
    ## $ against_rock      <dbl> 1, 1, 1, 2, 2, 4, 1, 1, 1, 2, 2, 4, 2, 2, 2, 2, 2, 2…
    ## $ against_steel     <dbl> 1.0, 1.0, 1.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 1.0, 1.…
    ## $ against_water     <dbl> 0.5, 0.5, 0.5, 2.0, 2.0, 2.0, 0.5, 0.5, 0.5, 1.0, 1.…
    ## $ attack            <dbl> 49, 62, 100, 52, 64, 104, 48, 63, 103, 30, 20, 45, 3…
    ## $ base_egg_steps    <dbl> 5120, 5120, 5120, 5120, 5120, 5120, 5120, 5120, 5120…
    ## $ base_happiness    <dbl> 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, 70, …
    ## $ base_total        <dbl> 318, 405, 625, 309, 405, 634, 314, 405, 630, 195, 20…
    ## $ capture_rate      <chr> "45", "45", "45", "45", "45", "45", "45", "45", "45"…
    ## $ classfication     <chr> "Seed Pokémon", "Seed Pokémon", "Seed Pokémon", "Liz…
    ## $ defense           <dbl> 49, 63, 123, 43, 58, 78, 65, 80, 120, 35, 55, 50, 30…
    ## $ experience_growth <dbl> 1059860, 1059860, 1059860, 1059860, 1059860, 1059860…
    ## $ height_m          <dbl> 0.7, 1.0, 2.0, 0.6, 1.1, 1.7, 0.5, 1.0, 1.6, 0.3, 0.…
    ## $ hp                <dbl> 45, 60, 80, 39, 58, 78, 44, 59, 79, 45, 50, 60, 40, …
    ## $ japanese_name     <chr> "Fushigidaneフシギダネ", "Fushigisouフシギソウ", "Fu…
    ## $ name              <chr> "Bulbasaur", "Ivysaur", "Venusaur", "Charmander", "C…
    ## $ percentage_male   <dbl> 88.1, 88.1, 88.1, 88.1, 88.1, 88.1, 88.1, 88.1, 88.1…
    ## $ pokedex_number    <dbl> 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 1…
    ## $ sp_attack         <dbl> 65, 80, 122, 60, 80, 159, 50, 65, 135, 20, 25, 90, 2…
    ## $ sp_defense        <dbl> 65, 80, 120, 50, 65, 115, 64, 80, 115, 20, 25, 80, 2…
    ## $ speed             <dbl> 45, 60, 80, 65, 80, 100, 43, 58, 78, 45, 30, 70, 50,…
    ## $ type_1            <chr> "grass", "grass", "grass", "fire", "fire", "fire", "…
    ## $ type_2            <chr> "poison", "poison", "poison", NA, NA, "flying", NA, …
    ## $ weight_kg         <dbl> 6.9, 13.0, 100.0, 8.5, 19.0, 90.5, 9.0, 22.5, 85.5, …
    ## $ generation        <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1…
    ## $ is_legendary      <dbl> 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0…

### Exploratory Data Analysis (EDA)

Our EDA focused on visualizing relationships between various Pokémon
attributes to understand the data better and prepare for modeling.
Techniques used included:

- **Scatter Plots:** Examining relationships between physical
  characteristics like height and weight.
- **Histograms and Density Plots:** Understanding the distribution of
  combat-relevant stats such as HP and Speed.
- **Bar Charts:** Analyzing the frequency of Pokémon types and gender
  distribution.
- **Box Plots:** Comparing attack stats across Pokémon types to identify
  which types tend to have higher or lower values.
- **Line Plots:** Tracking changes in experience growth across
  generations to observe evolution in game dynamics.

The analysis begins with visualizations that offer insights into the
physical attributes of Pokémon. A scatter plot depicting Pokémon height
versus weight reveals interesting patterns, with larger Pokémon
generally weighing more, though exceptions exist. Further exploration
through histograms and density plots uncovers distributions of
attributes such as HP and speed, providing a deeper understanding of the
variability within these traits.

Moving beyond physical attributes, we explore Pokémon types through bar
plots and pie charts. These visualizations showcase the frequency of
different Pokémon types and the distribution of gender within each type.
Understanding type distribution can be crucial for trainers strategizing
battles, as knowledge of type advantages and weaknesses can
significantly impact outcomes.

One of the highlights of this analysis is the exploration of Pokémon
stats. Box plots illustrate the distribution of attack values across
different Pokémon types, offering insights into which types tend to have
higher or lower attack stats. Similarly, line plots reveal how
experience growth varies across Pokémon types over different
generations, providing a glimpse into the evolution of training and
battling strategies.

### Statistical Analysis

We employed correlation matrices to unearth relationships between
various stats, revealing insights such as a positive correlation between
legendary status and speed, suggesting faster Pokémon are more likely to
be legendary. Heatmaps depicting damage taken against different types
offer valuable insights into type effectiveness, helping trainers make
informed decisions when selecting moves in battles.

### Random Forest Modeling

The predictive model was built using the Random Forest algorithm, chosen
for its robustness and efficacy in handling both categorical and
numerical data. After splitting the data into training and test sets, we
trained the model on 80% of the data, with the following results:

- **Accuracy: 99.38%**
- **Precision: 99.32%**
- **Recall (Sensitivity): 100%**
- **F1 Score: 99.66%**

These metrics indicate that our model was highly effective in predicting
the legendary status of Pokémon, showcasing the potential of machine
learning in analytical applications within the Pokémon universe.

## Conclusions and Future Work

The project demonstrated the power of data analysis and machine learning
in extracting actionable insights from complex datasets. Future work
could explore deeper interactions between different Pokémon types,
expand the analysis to include newer generations, and integrate more
granular data, such as move sets and battle outcomes, to refine
predictions and strategies further.

## Presentation

Our presentation can be found [here](presentation/presentation.html).

## Data

KUMAR NARASIMAN, V. (2024, March 21). project: Pokémon Dataset.
<https://www.kaggle.com/datasets/vimalkumarnarasiman/project-pokemon-dataset>.

## References

- Randomforest: Classification and regression with Random Forest.
  RDocumentation. (n.d.).
  <https://www.rdocumentation.org/packages/randomForest/versions/4.7-1.1/topics/randomForest>
- Khan, A. (n.d.). When to use smote?. Kaggle.
  <https://www.kaggle.com/discussions/questions-and-answers/427399>
- Yihui Xie, J. J. A. (2023, December 30). R markdown: The definitive
  guide. 7.3 Slide formatting.
  <https://bookdown.org/yihui/rmarkdown/xaringan-format.html>
- Function reference. • ggplot2. (n.d.).
  <https://ggplot2.tidyverse.org/reference/>
- KUMAR NARASIMAN, V. (2024, March 21). project: Pokémon Dataset.
  <https://www.kaggle.com/datasets/vimalkumarnarasiman/project-pokemon-dataset>.
