Project Proposal - Legendary Pokemon
================
Team White

``` r
library(tidyverse)
library(broom)
```

## 1. Introduction

Team White seeks to utilize a comprehensive dataset encompassing 802
Pokémon across all seven generations. This dataset is a treasure trove
of information, capturing various attributes such as base stats,
performance against other types, physical characteristics (height and
weight), classification, egg steps, experience points, abilities, and
more. It provides a unique blend of categorical and numerical data,
ranging from Pokémon names and types to their base stats and performance
metrics against different Pokémon types.

Ultimately, the question that our team is looking to answer with this
dataset is the predictive power to classify a Pokemon’s legendary status
based on other characteristics found in the dataset. The approach we’re
interested in taking to achieve this is outlined in more granular detail
in the data analysis plan to follow.

## 2. Data

``` r
poke_data <- read_csv("../data/pokemon.csv", show_col_types=FALSE)

glimpse(poke_data)
```

    ## Rows: 800
    ## Columns: 13
    ## $ `#`        <dbl> 1, 2, 3, 3, 4, 5, 6, 6, 6, 7, 8, 9, 9, 10, 11, 12, 13, 14, …
    ## $ Name       <chr> "Bulbasaur", "Ivysaur", "Venusaur", "VenusaurMega Venusaur"…
    ## $ `Type 1`   <chr> "Grass", "Grass", "Grass", "Grass", "Fire", "Fire", "Fire",…
    ## $ `Type 2`   <chr> "Poison", "Poison", "Poison", "Poison", NA, NA, "Flying", "…
    ## $ Total      <dbl> 318, 405, 525, 625, 309, 405, 534, 634, 634, 314, 405, 530,…
    ## $ HP         <dbl> 45, 60, 80, 80, 39, 58, 78, 78, 78, 44, 59, 79, 79, 45, 50,…
    ## $ Attack     <dbl> 49, 62, 82, 100, 52, 64, 84, 130, 104, 48, 63, 83, 103, 30,…
    ## $ Defense    <dbl> 49, 63, 83, 123, 43, 58, 78, 111, 78, 65, 80, 100, 120, 35,…
    ## $ `Sp. Atk`  <dbl> 65, 80, 100, 122, 60, 80, 109, 130, 159, 50, 65, 85, 135, 2…
    ## $ `Sp. Def`  <dbl> 65, 80, 100, 120, 50, 65, 85, 85, 115, 64, 80, 105, 115, 20…
    ## $ Speed      <dbl> 45, 60, 80, 80, 65, 80, 100, 100, 100, 43, 58, 78, 78, 45, …
    ## $ Generation <dbl> 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,…
    ## $ Legendary  <lgl> FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FAL…

## 3. Data analysis plan

Given the richness and diversity of this dataset, it presents an
excellent opportunity to apply machine learning (ML) techniques to
uncover patterns, predict outcomes, or classify Pokémon based on their
attributes. The project could aim to answer questions or solve problems
like predicting the legendary status of Pokémon, clustering Pokémon into
various groups based on similarities, or even predicting performance
outcomes in battles based on stats and types.

One potential machine learning method that can be applied to this
dataset is the Random Forest algorithm. Random Forest is an ensemble
learning technique that builds multiple decision trees during the
training phase and merges them together to get a more accurate and
stable prediction. It is particularly well-suited for datasets with a
high dimensionality, such as this one, with both predictive and
classification capabilities.

For example, the number of Legendary pokemon types is:

``` r
library(reshape2)
```

    ## 
    ## Attaching package: 'reshape2'

    ## The following object is masked from 'package:tidyr':
    ## 
    ##     smiths

``` r
is_legendary <- poke_data %>%
  filter(
    !is.na(Legendary),
    Legendary == TRUE
  )

count(is_legendary)
```

    ## # A tibble: 1 × 1
    ##       n
    ##   <int>
    ## 1    65

In order to achieve this, we will split the dataset into training and
testing sets. The approach we’ll take to splitting the dataset will be a
standard 80/20 split to start, with modifications as needed. To
implement the Random Forest classification algorithm, we can utilize the
[randomForest
package](https://cran.r-project.org/web/packages/randomForest/randomForest.pdf).
